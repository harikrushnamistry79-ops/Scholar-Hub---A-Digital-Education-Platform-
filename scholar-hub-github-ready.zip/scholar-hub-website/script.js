const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

$("#year").textContent = new Date().getFullYear();

const menuToggle = $("#menuToggle");
const navLinks = $("#navLinks");
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "×" : "☰";
});
$$(".nav-link").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

const searchInput = $("#courseSearch");
const filterButtons = $$(".filter-chip");
const courseCards = $$(".course-card");
let activeFilter = "all";

function filterCourses() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  courseCards.forEach(card => {
    const categoryMatches = activeFilter === "all" || card.dataset.category === activeFilter;
    const textMatches = !query || (card.dataset.title + " " + card.textContent).toLowerCase().includes(query);
    const show = categoryMatches && textMatches;
    card.hidden = !show;
    if (show) visible++;
  });
  $("#emptyState").hidden = visible > 0;
}
searchInput.addEventListener("input", filterCourses);
filterButtons.forEach(button => button.addEventListener("click", () => {
  filterButtons.forEach(item => item.classList.toggle("selected", item === button));
  activeFilter = button.dataset.filter;
  filterCourses();
}));

let toastTimeout;
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 3000);
}

const backdrop = $("#modalBackdrop");
const modalTitle = $("#modalTitle");
const modalDescription = $("#modalDescription");
const modalEyebrow = $("#modalEyebrow");
const modalSubmit = $("#modalSubmit");
const modalNote = $("#modalNote");
function openModal(mode = "join") {
  const login = mode === "login";
  modalEyebrow.textContent = login ? "WELCOME BACK" : "WELCOME TO SCHOLAR HUB";
  modalTitle.innerHTML = login ? "Good to see<br>you again." : "Your next chapter<br>starts here.";
  modalDescription.textContent = login ? "Enter your email to continue your learning journey." : "Join the community and make room for new ideas.";
  modalSubmit.innerHTML = login ? "Continue <span>→</span>" : "Join for free <span>→</span>";
  modalNote.textContent = "Demo only: this form does not create an account or send data.";
  backdrop.hidden = false;
  document.body.style.overflow = "hidden";
  setTimeout(() => $("#emailInput").focus(), 50);
}
function closeModal() {
  backdrop.hidden = true;
  document.body.style.overflow = "";
}
$("#joinBtn").addEventListener("click", () => openModal("join"));
$("#closingJoinBtn").addEventListener("click", () => openModal("join"));
$("#communityBtn").addEventListener("click", () => openModal("join"));
$("#loginBtn").addEventListener("click", () => openModal("login"));
$("#modalClose").addEventListener("click", closeModal);
backdrop.addEventListener("click", event => { if (event.target === backdrop) closeModal(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !backdrop.hidden) closeModal(); });
$("#joinForm").addEventListener("submit", event => {
  event.preventDefault();
  const email = $("#emailInput").value.trim();
  if (!email) return;
  closeModal();
  showToast(`Thanks! The demo form received ${email}. No account was created.`);
  event.target.reset();
});

$$(".learn-btn").forEach(button => button.addEventListener("click", () => {
  showToast(`${button.dataset.topic}: course details can be connected here.`);
}));
$("#showAllBtn").addEventListener("click", () => {
  activeFilter = "all";
  searchInput.value = "";
  filterButtons.forEach(button => button.classList.toggle("selected", button.dataset.filter === "all"));
  filterCourses();
  showToast("Showing all available topics.");
});
