# Scholar Hub — Learn. Connect. Grow.

A responsive, front-end learning community landing page built with HTML, CSS, and vanilla JavaScript.

## Features
- Responsive layout for mobile, tablet, and desktop
- Sticky navigation with mobile menu
- Topic cards with category filters and live search
- Join/login modal demo
- Toast notifications and interactive topic buttons
- No build tools or package installation required

## Run locally
1. Download or clone this repository.
2. Open `index.html` in your browser.

For a local development server, you can use the VS Code Live Server extension.

## Push to GitHub

```bash
git init
git add .
git commit -m "Add Scholar Hub website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Create an empty repository on GitHub first, then replace the remote URL above with your repository URL.

## Deploy on Netlify
1. Push the project to GitHub.
2. In Netlify, choose **Add new site → Import an existing project**.
3. Connect GitHub and select this repository.
4. Leave the build command blank and publish directory as `.` (the project root).
5. Deploy the site.

## Important
This is a front-end starter recreation inspired by the title “Scholar Hub — Learn. Connect. Grow.” It is not the original website source code. The login/join form is demo-only and does not create accounts or store or transmit submitted emails. Connect a real backend/authentication provider before using it for real users.
